from flask import Flask, request, jsonify
from flask_cors import CORS  # Import CORS
import json
import difflib  # Import for better intent matching

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes ✅

# Load intents (entities + responses)
with open("intents.json", "r", encoding="utf-8") as file:
    intents = json.load(file)

def get_response(user_input):
    user_input = user_input.lower()
    
    best_match = None
    highest_ratio = 0.6  # Threshold for matching similarity

    for intent in intents["intents"]:
        for pattern in intent["patterns"]:
            similarity = difflib.SequenceMatcher(None, user_input, pattern.lower()).ratio()
            if similarity > highest_ratio:
                highest_ratio = similarity
                best_match = intent

    if best_match:
        return best_match["responses"][0]  # Pick the first response

    return "I'm sorry, I don't understand. Can you rephrase?"

@app.route("/")  # Homepage Route ✅
def home():
    return "Chatbot is running! Use /chat for conversation."

@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json()
    user_message = data.get("message", "")
    bot_response = get_response(user_message)
    return jsonify({"response": bot_response})

if __name__ == "__main__":
    app.run(debug=True)
